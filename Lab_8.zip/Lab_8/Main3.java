class Main3{
	public static void main(String[] args) {
		Bank sbi=new SBI();
Bank icici= new ICICI();
Bank hdfc = new HDFC();

System.out.println("SBI interest :"+sbi.getInterest());

System.out.println("HDFC interest :"+hdfc.getInterest());
System.out.println("ICICI interest :"+icici.getInterest());
	}
}