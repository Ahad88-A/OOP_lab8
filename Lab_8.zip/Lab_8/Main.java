class Main{
	public static void main(String[] args) {
		Student s = new Student();
		
		 s.setName("Siddiqui");
		
		 s.setRollNumber(88);
		
		 s.setGrade('A');

		 s.displayInfo();
	}
}