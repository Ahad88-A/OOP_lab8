class Bank{
	

	public double getInterest(){
		return 0.0;
	}

}